package com.abel.report;

import com.abel.report.domain.Role;
import com.abel.report.domain.User;
import com.abel.report.repository.UserRepository;
import com.abel.report.service.RoleService;
import com.abel.report.service.UserService;
//import org.slf4j.LoggerFactory;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import java.util.logging.Logger;
import java.util.Collections;
import java.util.Set;
import java.util.logging.Logger;

@Component
public class TestRun implements CommandLineRunner {
    UserService userService;
    RoleService roleService;

    private BCryptPasswordEncoder encP;
    //private static final Logger logger= (Logger) LoggerFactory.getLogger(TestRun.class);

    @Override
    public void run(String ... args) throws Exception{
         //logger.info("-------------hl---------------");
         User user= new User();
         user.setFirst_name("alain");
         user.setLast_name("Bakole");
         user.setEmail("alainbakole55@gmail.com");
         user.setUsername("alainbakole55@gmail.com");
         user.setPassword(encP.encode("123"));
         Role role= new Role();
         role.setRole("SUPER_ADMIN");
         roleService.save(role);
         Set<Role> roles = null;
         roles.add(role);
         user.setRoles(roles);
         userService.save(user);
    }
}
