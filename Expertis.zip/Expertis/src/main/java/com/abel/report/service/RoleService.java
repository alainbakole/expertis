package com.abel.report.service;

import com.abel.report.domain.Role;
import com.abel.report.domain.User;
import com.abel.report.repository.RoleRepository;
import com.abel.report.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RoleService {
    @Autowired
    RoleRepository roleRepository;

    public void save(Role role){
        roleRepository.save(role);
    }
}
