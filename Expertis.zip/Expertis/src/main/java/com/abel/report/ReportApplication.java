package com.abel.report;

import com.abel.report.domain.Role;
import com.abel.report.domain.User;
import com.abel.report.repository.UserRepository;
import com.abel.report.service.RoleService;
import com.abel.report.service.UserService;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Set;
import java.util.logging.Logger;

@SpringBootApplication
@ComponentScan(basePackages = {"com.abel.report.*"})
@EntityScan(basePackages = {"com.abel.report.*"})
@EnableJpaRepositories(basePackages = {"com.abel.report.*"})
@EnableGlobalMethodSecurity(securedEnabled = true)
public class ReportApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReportApplication.class, args);
	}

	/*UserService userService;
	RoleService roleService;

	private BCryptPasswordEncoder encP;
	//private static final Logger logger= LoggerFactory.getLogger(com.abel.report.TestRun.class);

	@Override
	public void run(String ... args) throws Exception{
		//logger.info("-------------hl---------------");
		User user= new User();
		user.setFirst_name("alain");
		user.setLast_name("Bakole");
		user.setEmail("alainbakole55@gmail.com");
		user.setUsername("alainbakole55@gmail.com");
		user.setPassword(encP.encode("123"));
		Role role= new Role();
		role.setRole("SUPER_ADMIN");
		roleService.save(role);
		Set<Role> roles = null;
		roles.add(role);
		user.setRoles(roles);
		userService.save(user);
	} */
}

