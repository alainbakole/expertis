package com.abel.report.configuration;

public class SecurityConfiguration {

}
