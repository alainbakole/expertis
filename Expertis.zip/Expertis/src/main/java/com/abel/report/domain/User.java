package com.abel.report.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import javax.persistence.*;
import javax.sql.rowset.Joinable;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import java.util.Set;

@Data
@NoArgsConstructor
@ToString
@Entity
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long user_id;

    @NotNull
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinTable(name = "user_role", joinColumns = @JoinColumn(name="user_id"),inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles;

    @Column(columnDefinition = "VARCHAR(20)")
    @Max(value = 20)
    private String agent_id;

    @NotNull
    @Max(value = 50)
    @Column(columnDefinition = "VARCHAR(50) NOT NULL")
    private String first_name;

    @NotNull
    @Max(value = 50)
    @Column(columnDefinition = "VARCHAR(50) NOT NULL")
    private String last_name;

    @NotNull
    @Max(value = 50)
    @Column(columnDefinition = "VARCHAR(50) NOT NULL")
    private String username;

    @Column(columnDefinition = "DATE")
    private String dob;

    @Max(value = 50)
    @Column(columnDefinition = "VARCHAR(50)")
    private String department;

    @Max(value = 50)
    @Column(columnDefinition = "VARCHAR(50)")
    private String designation;

    @Max(value = 200)
    @Column(columnDefinition = "VARCHAR(200)")
    private String qualification;

    @Max(value = 200)
    @Column(columnDefinition = "VARCHAR(200)")
    private String work_exp;

    @Max(value = 20)
    @Column(columnDefinition = "VARCHAR(20)")
    private String contact_no;

    @Max(value = 20)
    @Column(columnDefinition = "VARCHAR(20)")
    private String emergency_contact_no;

    @Email
    @Max(value = 50)
    @NotNull
    @Column(columnDefinition = "VARCHAR(50)", unique = true)
    private String email;

    @Max(value = 10)
    @Column(columnDefinition = "VARCHAR(10)")
    private String marital_status;

    @Column(columnDefinition = "DATE")
    private String date_of_joining;

    @Column(columnDefinition = "DATE")
    private String date_of_leaving;

    @Max(value = 100)
    @Column(columnDefinition = "VARCHAR(100)")
    private String local_address;

    @Max(value = 100)
    @Column(columnDefinition = "VARCHAR(100)")
    private String permanent_address;

    @Max(value = 200)
    @Column(columnDefinition = "VARCHAR(200)")
    private String note;

    @Column(columnDefinition = "VARCHAR(100)")
    private String image;

    @Column(columnDefinition = "VARCHAR(100)")
    private String password;

    @Max(value = 10)
    @Column(columnDefinition = "VARCHAR(10)")
    private String gender;

    @Max(value = 100)
    @Column(columnDefinition = "VARCHAR(100)")
    private String bank_account_no;

    @Max(value = 100)
    @Column(columnDefinition = "VARCHAR(100)")
    private String bank_name;

    @Max(value = 100)
    @Column(columnDefinition = "VARCHAR(100)")
    private String contract_type;

    @Max(value = 50)
    @Column(columnDefinition = "VARCHAR(50)")
    private String basic_salary;

    @Column(columnDefinition = "VARCHAR(100)")
    private String cv;

    @Column(columnDefinition = "VARCHAR(100)")
    private String joining_letter;

    @Column(columnDefinition = "VARCHAR(100)")
    private String other_doc_name;

    @Column(columnDefinition = "VARCHAR(100)")
    private String other_doc_file;

    @Column(columnDefinition = "INT(11)")
    private int is_active;

    @Column(columnDefinition = "VARCHAR(100)")
    private String verification_code;
}
